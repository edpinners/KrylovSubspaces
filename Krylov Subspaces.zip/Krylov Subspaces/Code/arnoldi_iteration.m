function [Q, H] = arnoldi_iteration(A, v, m)
    % Input: A - input matrix
    %        v - starting vector
    %        m - number of iterations
    % Output: Q - matrix with orthonormal columns spanning the Krylov subspace
    %         H - Hessenberg matrix

    n = size(A, 1);
    Q = zeros(n, m);
    H = zeros(m, m);

    % Normalize the starting vector
    Q(:, 1) = v / norm(v);

    for j = 1:m
        % Multiply A with the current vector in Q
        w = A * Q(:, j);

        % Perform Gram-Schmidt orthogonalization
        for i = 1:j
            H(i, j) = Q(:, i)' * w;
            w = w - H(i, j) * Q(:, i);
        end

        % If we have not reached the last iteration, update Q and H
        if j < m
            H(j + 1, j) = norm(w);
            Q(:, j + 1) = w / H(j + 1, j);
        end
    end
end
