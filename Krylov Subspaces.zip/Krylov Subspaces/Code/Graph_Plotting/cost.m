function [J] = cost(y_hat,y)

J = [];%initialises J
n = length(y_hat);%finds length of y_hat
    J = (1/n) * sum((y_hat - y).^2);%calcs cost function
end
